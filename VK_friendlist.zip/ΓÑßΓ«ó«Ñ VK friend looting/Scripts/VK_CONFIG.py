VK_CONFIG = {
    "domain": "https://api.vk.com/method",
    "access_token": "2d9c2d752d9c2d752d9c2d750f2e892f7022d9c2d9c2d754924e57b3b7b327a1c66548b",
    "version": "5.124",
    "user_id": 147099787
}